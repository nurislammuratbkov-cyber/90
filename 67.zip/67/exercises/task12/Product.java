package task12;

public class Product {
    private final String name;
    private final double price;
    private final int quantity;

    Product(String name, double price, int quantity) {
        if (price < 0 || quantity < 0) throw new IllegalArgumentException();
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    double totalValue() { return price * quantity; }

    public static void main(String[] args) {
        System.out.println("1. " + new Student("Анна", 19, "ИВТ-1"));
        System.out.println("2. " + new Car("Toyota", "Corolla", 2021) + "; "
                + new Car("Kia", "Rio", 2019));
        System.out.println("3. " + new Book("Война и мир", "Лев Толстой", 1225));
        System.out.println("4. " + new Phone("Apple", "iPhone", 99990) + "; "
                + new Phone("Samsung", "Galaxy", 89990) + "; "
                + new Phone("Xiaomi", "Redmi", 24990));
        new Cat("Мурка", 3).meow();
        new Dog("Рекс", "овчарка").bark();
        Rectangle r = new Rectangle(5, 3);
        System.out.println("7. Площадь/периметр: " + r.area() + "/" + r.perimeter());
        System.out.println("8. Площадь круга: " + new Circle(4).area());
        System.out.println("9. " + new Employee("Иван", "инженер", 85000));
        Laptop l1 = new Laptop("Lenovo", 16, 75000), l2 = new Laptop("ASUS", 32, 110000);
        System.out.println("10. " + l1 + "; " + l2 + "; дороже: " + (l1.price > l2.price ? l1.brand : l2.brand));
        BankAccount b1 = new BankAccount("Алиса", 1000), b2 = new BankAccount("Борис", 2000);
        b1.deposit(500); b1.withdraw(300); b2.deposit(100); b2.withdraw(700);
        System.out.println("11-22. Счета: " + b1 + "; " + b2);
        Product p = new Product("Тетрадь", 80, 25);
        System.out.println("12. " + p.name + " на складе: " + p.totalValue());
        ExamStudent es1 = new ExamStudent("Алексей", 76), es2 = new ExamStudent("Мария", 43);
        System.out.println("13. Сдал? " + es1.passed() + "; " + es2.passed());
        Counter c = new Counter(); c.increment(); c.decrement();
        System.out.println("14. Счётчик: " + c.count);
        new Movie("Интерстеллар", "фантастика", 169).print();
        Temperature t = new Temperature(25);
        System.out.println("16. " + t.fahrenheit() + " F, " + t.kelvin() + " K");
        System.out.println("17. Расстояние: " + new Point(3, 4).distance());
        Cart cart = new Cart("Кружка", 450, 2); cart.setQuantity(3);
        System.out.println("18. Сумма корзины: " + cart.total());
        System.out.println("19. " + new Clock(9, 5, 7));
        Flight f = new Flight("SU123", "Москва", 1);
        System.out.println("20. Бронь: " + f.book() + ", повторная: " + f.book());
        new Computer("HP", "Intel i5", 16, 72000).print();
        new Computer("ASUS", "Ryzen 7", 32, 115000).print();
        new Computer("Apple", "M3", 16, 145000).print();
        LibraryBook book = new LibraryBook("Дюна", "Фрэнк Герберт");
        System.out.println("23. Выдача: " + book.borrow() + ", повторно: " + book.borrow());
        GradeStudent[] students = {new GradeStudent("Алия", 87), new GradeStudent("Данияр", 91),
                new GradeStudent("Марат", 78), new GradeStudent("София", 95), new GradeStudent("Егор", 89)};
        GradeStudent best = students[0];
        for (GradeStudent s : students) if (s.grade > best.grade) best = s;
        System.out.println("24. Лучший студент: " + best);
        MobilePhone phone = new MobilePhone("Nokia", 80); phone.turnOn(); phone.use(25);
        System.out.println("25. " + phone);
        CarTrip car = new CarTrip("Honda", 12000, 40); car.drive(150, 8);
        System.out.println("26. " + car);
        Order order = new Order("A-104", "Наушники", 6500, 2); order.setQuantity(3);
        System.out.println("27. Сумма заказа: " + order.total());
        Player warrior = new Player("Воин", 100, 35), mage = new Player("Маг", 60, 20);
        warrior.attack(mage); mage.attack(warrior); warrior.attack(mage);
        System.out.println("28. " + warrior + "; " + mage);
        Warehouse w = new Warehouse("Стулья", 8, 10);
        System.out.println("29. Добавить 3: " + w.add(3) + ", удалить 5: " + w.remove(5) + "; " + w);
        Teacher teacher = new Teacher("Елена Смирнова", "Программирование");
        System.out.println("30. " + new UniversityStudent("Амина", 19) + "; "
                + new UniversityStudent("Тимур", 20) + "; " + teacher + "; "
                + new Course("Основы Java", teacher, 72));
    }

    private static class Student {
        String name, group; int age;
        Student(String n, int a, String g) { name=n; age=a; group=g; }
        public String toString() { return name + ", " + age + ", " + group; }
    }
    private static class Car {
        String brand, model; int year;
        Car(String b, String m, int y) { brand=b; model=m; year=y; }
        public String toString() { return brand + " " + model + " " + year; }
    }
    private static class Book {
        String title, author; int pages;
        Book(String t, String a, int p) { title=t; author=a; pages=p; }
        public String toString() { return title + " — " + author + ", " + pages + " стр."; }
    }
    private static class Phone {
        String brand, model; double price;
        Phone(String b, String m, double p) { brand=b; model=m; price=p; }
        public String toString() { return brand + " " + model + ": " + price + " руб."; }
    }
    private static class Cat {
        String name; int age;
        Cat(String n, int a) { name=n; age=a; }
        void meow() { System.out.println("5. " + name + " мяукает: мяу!"); }
    }
    private static class Dog {
        String name, breed;
        Dog(String n, String b) { name=n; breed=b; }
        void bark() { System.out.println("6. " + name + " лает: гав!"); }
    }
    private static class Rectangle {
        double width, height;
        Rectangle(double w, double h) { if (w<=0 || h<=0) throw new IllegalArgumentException(); width=w; height=h; }
        double area() { return width*height; }
        double perimeter() { return 2*(width+height); }
    }
    private static class Circle {
        double radius;
        Circle(double r) { if (r<=0) throw new IllegalArgumentException(); radius=r; }
        double area() { return Math.PI*radius*radius; }
    }
    private static class Employee {
        String name, position; double salary;
        Employee(String n, String p, double s) { name=n; position=p; salary=s; }
        public String toString() { return name + ", " + position + ", " + salary + " руб."; }
    }
    private static class Laptop {
        String brand; int ram; double price;
        Laptop(String b, int r, double p) { brand=b; ram=r; price=p; }
        public String toString() { return brand + ", ОЗУ " + ram + " ГБ, " + price + " руб."; }
    }
    private static class BankAccount {
        String owner; double balance;
        BankAccount(String o, double b) { if (b<0) throw new IllegalArgumentException(); owner=o; balance=b; }
        void deposit(double a) { if (a<=0) throw new IllegalArgumentException(); balance+=a; }
        boolean withdraw(double a) {
            if (a<=0) throw new IllegalArgumentException();
            if (a>balance) return false;
            balance-=a; return true;
        }
        public String toString() { return owner + ": " + balance + " руб."; }
    }
    private static class ExamStudent {
        String name; int grade;
        ExamStudent(String n, int g) { if (g<0 || g>100) throw new IllegalArgumentException(); name=n; grade=g; }
        boolean passed() { return grade>=50; }
    }
    private static class Counter {
        int count;
        void increment() { count++; }
        void decrement() { count--; }
        void reset() { count=0; }
    }
    private static class Movie {
        String title, genre; int duration;
        Movie(String t, String g, int d) { title=t; genre=g; duration=d; }
        void print() { System.out.println("15. " + title + " | " + genre + " | " + duration + " мин."); }
    }
    private static class Temperature {
        double celsius;
        Temperature(double c) { if (c < -273.15) throw new IllegalArgumentException(); celsius=c; }
        double fahrenheit() { return celsius*9/5+32; }
        double kelvin() { return celsius+273.15; }
    }
    private static class Point {
        double x, y;
        Point(double x, double y) { this.x=x; this.y=y; }
        double distance() { return Math.hypot(x,y); }
    }
    private static class Cart {
        String name; double price; int quantity;
        Cart(String n, double p, int q) { name=n; price=p; setQuantity(q); }
        double total() { return price*quantity; }
        void setQuantity(int q) { if (q<0) throw new IllegalArgumentException(); quantity=q; }
    }
    private static class Clock {
        int hours, minutes, seconds;
        Clock(int h, int m, int s) {
            if (h<0 || h>23 || m<0 || m>59 || s<0 || s>59) throw new IllegalArgumentException();
            hours=h; minutes=m; seconds=s;
        }
        public String toString() { return String.format("%02d:%02d:%02d", hours, minutes, seconds); }
    }
    private static class Flight {
        String number, destination; int seats;
        Flight(String n, String d, int s) { if (s<0) throw new IllegalArgumentException(); number=n; destination=d; seats=s; }
        boolean book() { if (seats==0) return false; seats--; return true; }
    }
    private static class Computer {
        String brand, processor; int ram; double price;
        Computer(String b, String p, int r, double c) { brand=b; processor=p; ram=r; price=c; }
        void print() { System.out.println("21. " + brand + ", " + processor + ", " + ram + " ГБ, " + price + " руб."); }
    }
    private static class LibraryBook {
        String title, author; boolean available=true;
        LibraryBook(String t, String a) { title=t; author=a; }
        boolean borrow() { if (!available) return false; available=false; return true; }
        void returnBook() { available=true; }
    }
    private static class GradeStudent {
        String name; double grade;
        GradeStudent(String n, double g) { if (g<0 || g>100) throw new IllegalArgumentException(); name=n; grade=g; }
        public String toString() { return name + " (" + grade + ")"; }
    }
    private static class MobilePhone {
        String brand; int battery; boolean on;
        MobilePhone(String b, int level) { if (level<0 || level>100) throw new IllegalArgumentException(); brand=b; battery=level; }
        void turnOn() { if (battery>0) on=true; }
        void turnOff() { on=false; }
        void use(int amount) { if (amount<0) throw new IllegalArgumentException(); battery=Math.max(0,battery-amount); if (battery==0) on=false; }
        public String toString() { return brand + ", заряд " + battery + "%, " + (on ? "включён" : "выключен"); }
    }
    private static class CarTrip {
        String brand; double mileage, fuel;
        CarTrip(String b, double m, double f) { if (m<0 || f<0) throw new IllegalArgumentException(); brand=b; mileage=m; fuel=f; }
        boolean drive(double km, double consumption) {
            if (km<0 || consumption<0) throw new IllegalArgumentException();
            double used=km*consumption/100;
            if (used>fuel) return false;
            mileage+=km; fuel-=used; return true;
        }
        public String toString() { return brand + ", пробег " + mileage + " км, топливо " + fuel + " л"; }
    }
    private static class Order {
        String number, product; double price; int quantity;
        Order(String n, String p, double c, int q) { number=n; product=p; price=c; setQuantity(q); }
        double total() { return price*quantity; }
        void setQuantity(int q) { if (q<0) throw new IllegalArgumentException(); quantity=q; }
    }
    private static class Player {
        String name; int health, damage;
        Player(String n, int h, int d) { if (h<0 || d<0) throw new IllegalArgumentException(); name=n; health=h; damage=d; }
        void attack(Player p) { p.health=Math.max(0,p.health-damage); }
        public String toString() { return name + ": здоровье " + health; }
    }
    private static class Warehouse {
        String product; int quantity, capacity;
        Warehouse(String p, int q, int c) { if (q<0 || c<q) throw new IllegalArgumentException(); product=p; quantity=q; capacity=c; }
        boolean add(int n) { if (n<=0) throw new IllegalArgumentException(); if (n>capacity-quantity) return false; quantity+=n; return true; }
        boolean remove(int n) { if (n<=0) throw new IllegalArgumentException(); if (n>quantity) return false; quantity-=n; return true; }
        public String toString() { return product + ": " + quantity + "/" + capacity; }
    }
    private static class UniversityStudent {
        String name; int age;
        UniversityStudent(String n, int a) { name=n; age=a; }
        public String toString() { return "Студент " + name + ", " + age + " лет"; }
    }
    private static class Teacher {
        String name, subject;
        Teacher(String n, String s) { name=n; subject=s; }
        public String toString() { return "Преподаватель " + name + " (" + subject + ")"; }
    }
    private static class Course {
        String name; Teacher teacher; int hours;
        Course(String n, Teacher t, int h) { name=n; teacher=t; hours=h; }
        public String toString() { return "Курс " + name + ", " + hours + " ч., " + teacher; }
    }
}
